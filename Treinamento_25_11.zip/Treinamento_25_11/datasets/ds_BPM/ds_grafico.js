function defineStructure() {

}
function onSync(lastSyncDate) {

}
function createDataset(fields, constraints, sortFields) {
	
	var dataset = DatasetBuilder.newDataset ();
	
	dataset.addColumn("Produto");
	dataset.addColumn("Valor");
	
	dataset.addRow(new Array ("Mesa", 350));
	dataset.addRow(new Array ("Cadeira", 1000));
	dataset.addRow(new Array ("Sofa", 550));
	dataset.addRow(new Array ("Cama", 450));
	dataset.addRow(new Array ("TV", 950));
	dataset.addRow(new Array ("Chuveiro", 750));
	dataset.addRow(new Array ("Prato", 650));
	dataset.addRow(new Array ("Geledeira", 850));
	dataset.addRow(new Array ("Fogão", 750));
	
	return dataset;

}function onMobileSync(user) {

}