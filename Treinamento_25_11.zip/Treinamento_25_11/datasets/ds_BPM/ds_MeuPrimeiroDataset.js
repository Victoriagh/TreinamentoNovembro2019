function defineStructure() {

}
function onSync(lastSyncDate) {

}
function createDataset(fields, constraints, sortFields) {
	
	var dataset = DatasetBuilder.newDataset ();
	
	//Cria Colunas
	dataset.addColumn("Sigla");
	dataset.addColumn("Estado");
	dataset.addColumn("Capital");
	dataset.addColumn("Area");
	
	//Cria Linhas
	dataset.addRow(new Array ("AM", "Amazonas", "Manaus", 8739273));
	dataset.addRow(new Array ("PA", "Para", "Belém", 8739273));
	dataset.addRow(new Array ("MT", "Mato Grosso", "Cuiába", 8739273));
	dataset.addRow(new Array ("TO", "Tocantins", "Palmas", 8739273));
	dataset.addRow(new Array ("PI", "Piauí", "Teresina", 8739273));
	
	return dataset;
	

}function onMobileSync(user) {

}