var MyWidget = SuperWidget.extend({
    //variáveis da widget
    variavelNumerica: null,
    variavelCaracter: null,

    //método iniciado quando a widget é carregada
    init: function() {
    	
      	var dataset = DatasetFactory.getDataset("ds_grafico", null, null, null);
    	var dados = [];
    	var dados1 = [];
    
    	
    	for(var x=0; x < dataset.values.length; x++) {
    		dados[x] = dataset.values[x].Produto;
    		dados2[x] = dataset.values[x].Valor;
    		
    	}
    	

    	var data = {
    		    labels: dados,
    		    datasets: [
    		        {
    		            label: "My First dataset",
    		            fillColor: "rgba(220,220,220,0.2)",
    		            strokeColor: "rgba(220,220,220,1)",
    		            pointColor: "rgba(220,220,220,1)",
    		            pointStrokeColor: "#fff",
    		            pointHighlightFill: "#fff",
    		            pointHighlightStroke: "rgba(220,220,220,1)",
    		            data: dados2
    		        };
    		        
    		        var chart = FLUIGC.chart('#MY_SELECTOR', {
    		    	    id: 'set_an_id_for_my_chart',
    		    	    width: '700',
    		    	    height: '200',
    		    	    /* See the list of options */
    		    	});
    		    	// call the line function
    		    	var lineChart = chart.line(data, "");
    		    	
        	
    },
  
    //BIND de eventos
    bindings: {
        local: {
            'save': ['click_save']
        },
        global: {}
    },
 
    
    
});
    	

    	
    	
    	
    	
    	
    	
    	
    	
    	
    	
    	
    	
    	
    	
    	
    	
    	
    	
    	
 
