console.log ("estou usando javascript")

$("#cep").blur(function (){
	var cep = $("#cep").val();
	
	$.getJSON("https://viacep.com.br/ws/"+cep+"/json/", function (data){
		$("#endereco").val(data.logradouro);
	})
})