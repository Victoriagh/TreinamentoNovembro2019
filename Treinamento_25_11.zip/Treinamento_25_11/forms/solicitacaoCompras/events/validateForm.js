function validateForm(form){
	
	//coleta de dados
	var atual = getValue("WKNumState");
	
	var inicio = "7";
	var analisar_gestor = "8";
	var analisar_financ = "25";
	
	//Arrays
	
	var valida = [];
	
		if (atual == inicio){
			valida.push("ramal");
		}
		
	
		for (var i=0; i<valida.length; i++){
			if(form.getValue(valida[i])== null || form.getValue(valida[i]).trim()== ""){
				throw("O campo" +valida[i]+  " precisa ser preenchido.");
		}
	}
		
	var index = [i];

		for(var i = 0; i < index.length; i++){

			if (form.getValue("descricao_prod___"+index[i]) == null || form.getValue("descricao_prod___"+index[i]) == ''){
			throw "O Campo 'Descrição Produto' precisa ser preenchido.";
			}

			if (form.getValue("quantidade_prod___"+index[i]) == null || form.getValue("quantidade_prod___"+index[i]) == ''){
			throw "O Campo 'Quantidade Produto' precisa ser preenchido.";
			}

			if (form.getValue("valUnit_prod___"+index[i]) == null || form.getValue("valUnit_prod___"+index[i]) == ''){
			throw "O Campo 'Valor Unitario' precisa ser preenchido.";
			}

			if (form.getValue("valTotal_prod___"+index[i]) == null || form.getValue("valTotal_prod___"+index[i]) == ''){
			throw "O Campo 'Valor Total' precisa ser preenchido.";
			}


			}
		
}