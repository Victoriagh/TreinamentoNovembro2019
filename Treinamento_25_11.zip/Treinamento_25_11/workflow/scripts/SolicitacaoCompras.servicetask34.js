function servicetask34(attempt, message) {
	
	var ccod = hAPI.getCardValue("cod_prod")
	var cdescr = hAPI.getCardValue("desc_prod")
	var ctipo = hAPI.getCardValue("tipo_prod")
	
	var c1 = DatasetFactory.createConstraint("ccod", ccod, ccod, ConstraintType.MUST);
	var c2 = DatasetFactory.createConstraint("cdescr", cdescr, cdescr, ConstraintType.MUST );
	var c3 = DatasetFactory.createConstraint("ctipo", ctipo, ctipo, ConstraintType.MUST);
	var params = new Array (c1, c2, c3);
	var dataset = DatasetFactory.getDataset ("ds_baseInclusao", null, params, null); 
	
	return dataset; 
	
	if (dataset == "1") {
        return true;
    } else {
        throw "Exemplo de Erro";
    }
	
}